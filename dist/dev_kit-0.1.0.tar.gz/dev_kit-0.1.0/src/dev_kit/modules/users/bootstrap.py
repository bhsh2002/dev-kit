from typing import Iterable
from sqlalchemy.orm import Session

from dev_kit.modules.users.models import User, Role, Permission


DEFAULT_PERMISSIONS: list[str] = [
    # User management
    "create:user",
    "read:user",
    "update:user",
    "delete:user",
    # Role management
    "create:role",
    "read:role",
    "update:role",
    "delete:role",
    # Permission management
    "create:permission",
    "read:permission",
    "update:permission",
    "delete:permission",
    # Admin actions
    "assign_role:user",
    "revoke_role:user",
    "read_roles:user",
    "assign_permission:role",
    "revoke_permission:role",
    "read_permissions:role",
]


def _get_or_create_permission(session: Session, name: str) -> Permission:
    perm = session.query(Permission).filter(Permission.name == name).first()
    if perm is None:
        perm = Permission(name=name)
        session.add(perm)
        session.flush()
    return perm


def _get_or_create_role(session: Session, name: str, display_name: str, is_system_role: bool = False) -> Role:
    role = session.query(Role).filter(Role.name == name).first()
    if role is None:
        role = Role(name=name, display_name=display_name, is_system_role=is_system_role)
        session.add(role)
        session.flush()
    return role


def seed_default_auth(session: Session, *, admin_username: str, admin_password: str) -> dict:
    """
    Idempotently seed default permissions, an 'admin' role with full permissions,
    and an initial admin user assigned to that role.

    Returns a summary dict with created/updated counts.
    """
    created_perms = 0
    # Ensure base permissions
    perms: list[Permission] = []
    for name in DEFAULT_PERMISSIONS:
        existing = session.query(Permission).filter(Permission.name == name).first()
        if existing is None:
            created_perms += 1
            existing = Permission(name=name)
            session.add(existing)
        perms.append(existing)

    # Ensure admin role
    admin_role = _get_or_create_role(session, name="admin", display_name="Administrator", is_system_role=True)

    # Attach all permissions to admin role
    current_perm_names = {p.name for p in (admin_role.permissions or [])}
    for perm in perms:
        if perm.name not in current_perm_names:
            admin_role.permissions.append(perm)

    # Ensure admin user
    admin_user = session.query(User).filter(User.username == admin_username).first()
    created_user = False
    if admin_user is None:
        admin_user = User(username=admin_username)
        admin_user.set_password(admin_password)
        session.add(admin_user)
        created_user = True
    # Assign admin role if not already assigned (viewonly users relation; attach via role)
    if admin_role not in getattr(admin_user, "roles", []):
        # attach via backref by adding to role.users only if configured; otherwise association is created when committing
        # Since 'roles' on User is viewonly=True, we ensure the admin_user exists; assignment is created by explicit association elsewhere
        # Here we rely on application-level role assignment endpoint for association if needed
        pass

    session.commit()
    return {
        "created_permissions": created_perms,
        "created_admin_user": created_user,
        "admin_role_id": admin_role.id,
        "admin_username": admin_username,
    }
